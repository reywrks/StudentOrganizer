//
//  NoteCell.swift
//  StudentOrganizer
//
//  One square card in the notes grid: a photo (or an icon) and the note text.
//

import UIKit

class NoteCell: UICollectionViewCell {

    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var noteLabel: UILabel!

    // Called once when the cell is loaded from the storyboard: set up its look.
    override func awakeFromNib() {
        super.awakeFromNib()
        layer.cornerRadius = 12
        clipsToBounds = true
        // Frosted-glass card instead of a solid gray one (our own style choice).
        backgroundColor = .clear
        backgroundView = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterial))
        photoImageView.clipsToBounds = true
        // Bigger icon for text-only notes, so the card does not look empty.
        photoImageView.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 34)
    }

    /// Fills the cell with one Note from the database.
    func configure(with note: Note) {
        noteLabel.text = note.text

        if let data = note.photoData, let image = UIImage(data: data) {
            photoImageView.image = image
            photoImageView.contentMode = .scaleAspectFill   // fill the square, crop extra
        } else {
            // No photo: show a text icon instead.
            photoImageView.image = UIImage(systemName: "text.alignleft")
            photoImageView.contentMode = .center
            photoImageView.tintColor = .secondaryLabel   // readable on the glass card
        }
    }

    // Cells are reused while scrolling, so clear the old picture first.
    override func prepareForReuse() {
        super.prepareForReuse()
        photoImageView.image = nil
    }
}
